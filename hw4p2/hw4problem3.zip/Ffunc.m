function y = Ffunc( x )
%FFUNC Summary of this function goes here
%   Detailed explanation goes here

y=(1-x.*x);
end

